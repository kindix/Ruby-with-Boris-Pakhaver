p 5
p 5.next
p 5.to_s
puts

name = "Andrii"

p "Hello #{name} how are you"


age = 33

p "I am " + age.to_s + " age old"
p "I am #{age} age old"

p "1 + 1 = #{d = 1 + 1}"

p d
