p "whimper".sub("er", "or") # change one time
p "whimper er er".gsub("er", "or") # change always time

# here BANG ! change word

voicemail = "I can be reached at (066)49-400-95 or kindix.ak@gmail.com sfs@gmail.com"
p voicemail.scan(/[\d+]/).join
p voicemail.gsub(/\d/, "0")
p voicemail.gsub(/[\d+\)\(-]/, "")
puts "(555)-555 1234".gsub(/[^0-9]/, "")

number = "sf  sfsdf (066)-49-400-95 sfs sff"

p number.gsub(/[^\d+\(\)\-]/, "")
p number.gsub(/[^0-9]/, "")

p voicemail.gsub(/\w+/) { |word| word.capitalize}
p voicemail.scan(/\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}\b/i).join
p voicemail.scan(/[\w+.%_+-]+@+[\w+.]+/)
p voicemail.scan(/[\d+\(\)\-]+/)


require 'benchmark' # Might be necessary.

def foo
  voicemail = "I can be reached at (066)49-400-95 or kindix.ak@gmail.com"
  Benchmark.bm( 20 ) do |bm|  # The 20 is the width of the first column in the output.
    bm.report( "Access Database:" ) do
      [1, 2, 3, "Hello"].join.scan(/\d/).map { |elem| elem.to_i}.inject(:+)
    end

    bm.report( "Access Redis:" ) do
      voicemail.scan(/[\w+.%_+-]+@+[\w+.]+/)
    end
  end
end

foo()
