str = "Hello World Ruby is amazing!"

p str.end_with?("")

def custom_start_with?(str, substr = "")
  return nil unless str.include?(substr)
  str[0, substr.length] == substr
end

def custom_end_with?(str, substr = "")
  return nil unless str.include?(substr)
  str[-1, substr.length] == substr
end

def custom_include?(str, substr)
  length = substr.length
  str.chars.each_with_index { |elem, index|
    seq = str[index, length]
    return true if seq == substr}
  false
end

p custom_start_with?(str, "l")
p custom_end_with?(str, "zing")
p custom_include?(str, "!")
