str = "Hello World!"
voicemail = "I can be reached at (066)49-400-95 or kindix.ak@gmail.com"
p //.class
p str =~ /!/ # return index of position or nil if not find
p str =~ /./ # find anything character WILDCARD #207
puts "=================================="
p str =~ /Wo/

p voicemail.scan(/[ro]/) # find or "r" or "o"

p voicemail.scan(/\d+/) # find all digits
p voicemail.scan(/\w+/) # find all words

arr = voicemail.scan(/\d+/).map { |elem| elem.to_i }

def sum(arr)
  sum = 0
  arr.each do |elem|
    sum += elem
  end
  sum
end

p sum(arr)


Regex_Pattern = '[a-zA-Z0-9]'

Test_String = "123.456.abc.def"
regex = !/#{Regex_Pattern}/.match(Test_String).nil?
print regex
