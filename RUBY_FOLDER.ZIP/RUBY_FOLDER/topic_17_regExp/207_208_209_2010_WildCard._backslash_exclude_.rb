# https://rubular.com/

voicemail = "I can be reached at 06 49-40095 or kindix.ak@gmail.com"

p voicemail =~ /./  #find anything and return index of first character
p voicemail.scan(/./) #find anything
p voicemail.scan(/\./) # find a "dod"

p voicemail.scan(/\s+/).length

p voicemail.scan(/com\z/) #end of string
p voicemail.scan(/\A\d+/) #start of string


p voicemail.scan(/[^aieuo]/) # [^everithing] delete

puts "========================================"
regex = /(\d{1,3})[- ](\d{1,3})[- ](\d{4,10})/
match = regex.match(voicemail)
puts "CountryCode=#{match[1]},LocalAreaCode=#{match[2]},Number=#{match[3]}"
