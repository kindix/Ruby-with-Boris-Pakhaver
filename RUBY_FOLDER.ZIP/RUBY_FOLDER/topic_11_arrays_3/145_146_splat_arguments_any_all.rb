
def sum(*numbers)
  sum = 0
  numbers.each { |elem| sum += elem}
  sum
end
sum(1, 2, 3)


p [1, 3, 7, 2].any? { |num| num.even?}
p [1, 3, 7, 2].all? { |num| num.even?}
