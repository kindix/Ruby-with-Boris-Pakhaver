arr_1 = [1, 2, 3, 2]
arr_2 = [3, 4, 5, 1, 1]

p arr_1 & arr_2

def custom_inter(arr1, arr2)
  new_arr = []
  arr1.each { |elem| new_arr << elem if arr2.include?(elem)}
  new_arr
end

p custom_inter(arr_1, arr_2)
