arr_1 = [1, 2, 3]
arr_2 = [3, 4, 5]

p arr_1 - arr_2

def custom_sub(arr1, arr2)
  new_arr = []
  arr1.each { |elem| new_arr << elem unless arr2.include?(elem)}
  new_arr
end

custom_sub(arr_1, arr_2)
