any_arr = [[1, 2], [1, 3, 5], [2, 5, 7]]

p any_arr.flatten(1)

names = %w[Boo Moe Joe Good]
registation = [true, true, false]
p names.zip(registation)


def custom_zip(arr1, arr2)
  new_arr = []
  arr1.each_with_index { |elem, index| new_arr << [elem, arr2[index]]}
  new_arr
end

p custom_zip(names, registation).to_h
