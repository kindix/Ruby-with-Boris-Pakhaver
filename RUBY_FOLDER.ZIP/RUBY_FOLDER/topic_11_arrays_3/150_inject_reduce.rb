numbers = [1, 2, 3, 4, 5, 6]

p numbers.inject(0) { |prev, curr| prev + curr}
p (1..5).inject { |prev, curr|  prev * curr}
