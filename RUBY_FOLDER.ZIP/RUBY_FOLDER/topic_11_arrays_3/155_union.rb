arr_1 = [1, 2, 3]
arr_2 = [3, 4, 5]

p arr_1 | arr_2


def custom_union(arr1, arr2)
  arr1.concat(arr2).uniq
end

p custom_union(arr_1, arr_2)
