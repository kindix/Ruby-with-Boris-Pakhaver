words = %w[dictionary refregirator platyrus microwave]


words.select do |word|
  if word.length > 9
    p word
    break
  end
end

p words.find { |word| word.length > 9}
p words.detect { |word| word.length > 9}

lottery = [4 ,8, 15, 16, 23, 42]

p lottery.reverse.find { |num| num.odd?}
p lottery.partition { |num| num.odd?}
