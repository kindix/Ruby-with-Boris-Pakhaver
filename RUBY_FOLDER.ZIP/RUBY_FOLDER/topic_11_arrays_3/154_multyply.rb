p arr_1 * 5

def custom_multiply(arr, num)
  new_arr = []
  num.times { new_arr << arr }
  # num.times { arr.each { |i| new_arr << i}}
end


p custom_multiply(arr_1, 3)
