
a = [1, 2, 3]
b = a
c = a.dup


p a.object_id
p b.object_id
p c.object_id

p c.object_id == a.object_id #false if dup

c.push(100)
a.push(4)
p c
p a
p b
