numbers = [1, 2, nil, 4, nil]

p numbers.compact!


def custom_compact(arr)
  new_arr = []
  arr.each { |elem| new_arr << elem unless nil}
  new_arr
end

custom_compact(numbers)
