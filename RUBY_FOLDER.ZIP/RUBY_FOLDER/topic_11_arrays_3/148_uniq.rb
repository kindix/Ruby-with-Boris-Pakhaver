numbers = [1, 2, 4, 3, 3, 1, 3, 7, 8, 9, 4, 4]

p numbers.sort


def custom_uniq(arr)
  new_arr = []
  arr.sort.each_with_index { |elem| new_arr << elem unless new_arr.include?(elem)}
  new_arr
end

p custom_uniq(numbers)
