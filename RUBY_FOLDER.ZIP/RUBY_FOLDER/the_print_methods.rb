puts "Hello"
puts  "world!"
puts
print "Hello"
print " world!"
