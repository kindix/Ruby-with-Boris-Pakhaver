# super without parentathes
# class Car
#   def drive
#     "Room, Room!!"
#   end
# end
#
# class FireTruck < Car
#   def drive(speed)
#     super + " Beep, Beep!!!"
#   end
# end

# super with parentathes but without arguments
# class Car
#   def drive
#     "Room, Room!!"
#   end
# end
#
# class FireTruck < Car
#   def drive(speed)
#     super() + " Beep, Beep!!!, Im going #{speed} km/hour"
#   end
# end


# super with parentathes and with arguments
class Car

  attr_accessor :maker

  def initialize(maker)
    @maker = maker
  end
  def drive
    "Room, Room!!"
  end
end

class FireTruck < Car

  attr_accessor :sirens

  def initialize(maker, sirens)
    super(maker)
    @sirens = sirens
  end
  def drive(speed)
    super() + " Beep, Beep!!!, Im going #{speed} km/hour and i have #{sirens} sirens"
  end
end
ft = FireTruck.new("Volvo", 2)
p ft.drive(45)
