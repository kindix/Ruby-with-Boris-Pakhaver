class Player
  def play_game
    rand(1..100) > 50 ? "Winner" : "Loser"
  end
end



player_1 = Player.new
player_2 = Player.new

def player_2.play_game
  "Winner"
end

p player_1.play_game
p player_2.play_game
p player_2.singleton_methods
p player_2.singleton_class
