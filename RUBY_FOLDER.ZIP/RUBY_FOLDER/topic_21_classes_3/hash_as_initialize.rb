class Candidate
  attr_accessor :name, :age, :birthplace

  def initialize(name, details = {})
    default = {age: 33, birthplace: "DE"}
    default.merge!(details)
    @name = name
    @age = default[:age]
    @birthplace = default[:birthplace]
  end
end


z1 = Candidate.new("Andrii", age: 23)

p z1.name
p z1.age
p z1.birthplace
