class Employee

  attr_accessor :age
  attr_reader :name

  def initialize(name, age)
    @name = name
    @age = age
  end

  def introduce
    "Hi my #{name} is and i am #{age} years old"
  end
end

class Manager < Employee

  attr_accessor :rank

  def initialize(name, age, rank)
    super(name, age)
    @rank = rank
  end

  def introduce
    super + " and im a meneger from #{self.class}"
  end

  def yell
    "Who is a boss? #{name} is a boss"
  end
end

bob = Manager.new("Bob", 48, "manager")

p bob.introduce
