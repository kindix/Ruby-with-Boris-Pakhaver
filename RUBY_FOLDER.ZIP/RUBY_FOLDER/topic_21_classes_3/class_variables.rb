class Product
  @@product_counter = 0

  def self.counter
    @@product_counter
  end

  def initialize
    @@product_counter += 1
  end
end


class Widget < Product
  @@widget_counter = 0
  def self.counter
    @@widget_counter
  end

  def initialize
    super
    @@widget_counter += 1
  end
end



a = Product.new
b = Product.new
c = Product.new
d = Widget.new
e = Widget.new
f = Widget.new
g = Widget.new
p "#{Product.counter} from the begin"
p Widget.counter
