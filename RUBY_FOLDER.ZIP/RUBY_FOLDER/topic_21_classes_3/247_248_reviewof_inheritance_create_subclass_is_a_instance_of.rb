class Employee

  attr_accessor :age
  attr_reader :name

  def initialize(name, age)
    @name = name
    @age = age
  end

  def introduce
    "Hi my #{name} is and i am #{age} years old"
  end
end

class Manager < Employee
  def introduce
    "Hi im a #{name} and im a meneger from #{self.class}"
  end

  def yell
    self.instance_of?(Manager) ? "Who is a boss? #{name} is a boss" : "You are not a boss"
  end
end

class Worker < Manager
end

bob = Manager.new("Bob", 44)
andrii = Employee.new("Andrii", 33)
sisil = Worker.new("Sisil", 25)
p andrii.introduce
p bob.introduce
p bob.yell
p sisil.introduce
puts bob.respond_to?("introduce")

p Manager.ancestors
p Worker.ancestors

p Manager < BasicObject # check superclass

p bob.is_a?(Object) #true #respond to all [] from ancestors
p bob.instance_of?(Object) #false
