#
#
#


=begin
p 1 + 2
print "Hello world"
=end


#Закоментить виділений текст: select - ctrl + /

p 1 + 2
print "Hello world"
