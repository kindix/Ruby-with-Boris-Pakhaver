# txt_file_read = File.open("novel.txt").each { |line| puts line.chomp}

# p txt_file
# "r" - read, "w" - write, "a" append tothe end of file
txt_file_wrire = File.open("first_file.txt", "a") { |file|
  file.puts "I'm create that from RUBY"
  file.write "Line brake here\n"

}
