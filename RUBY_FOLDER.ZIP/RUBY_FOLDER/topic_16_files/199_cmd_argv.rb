ARGV.each do |arg|
  num = arg.to_i
  puts "Square of #{num} is #{num ** 2}"
end
