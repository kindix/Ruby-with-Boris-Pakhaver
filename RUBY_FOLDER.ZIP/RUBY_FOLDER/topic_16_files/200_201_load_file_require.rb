p "Start file"

# load "./end.rb"
# load "end.rb"
#
# require "./end.rb"
require_relative "end"
