 # File.rename("first_file.txt", "renamed_file")
 if File.exist?("renamed_file")
   File.delete("renamed_file")
 end
