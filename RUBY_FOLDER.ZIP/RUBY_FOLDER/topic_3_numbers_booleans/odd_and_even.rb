number = 11
p number.odd?
p number.even?

p 21.32.to_i.odd?
