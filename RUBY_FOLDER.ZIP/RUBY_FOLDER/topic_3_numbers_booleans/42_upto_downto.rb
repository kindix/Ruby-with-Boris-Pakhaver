10.downto(1) { |count| p count }

1.upto(5) {|i| p i * 3}
