p false.class
p 5 < 10
