p 20.next()
p 20 + 1
p 20.+(1)

puts

p 10 - 2
p 10.-(2)

puts

p 10 % 3
p 10.%(3)
