p 3 == 4

p "3".to_i == 3
p Integer == Integer
p 5 == 5.0
