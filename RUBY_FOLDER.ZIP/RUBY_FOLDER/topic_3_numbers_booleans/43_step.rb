fives = []
5.step(100,5) {|i| fives.push(i)}

p fives
