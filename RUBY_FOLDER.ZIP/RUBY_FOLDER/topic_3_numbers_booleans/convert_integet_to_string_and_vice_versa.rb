str = "5"

p str.class
p str.to_i
p str.to_f

puts

number = 10

p number.class
p number.to_s.class
