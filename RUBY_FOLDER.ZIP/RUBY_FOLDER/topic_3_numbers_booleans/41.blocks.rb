 5.times {p "Andrii a good man".split}

 3. times {|count| p "we are on a loop #{count.next}"}


10.times {|number| p "#{3 * number.next}".to_i }


5.times do
  |number|
  p number
  p number**number
end
