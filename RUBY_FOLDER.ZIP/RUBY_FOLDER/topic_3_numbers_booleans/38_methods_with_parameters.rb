
p 4.between?(1, 5)

p 3.between?(1, 2)
