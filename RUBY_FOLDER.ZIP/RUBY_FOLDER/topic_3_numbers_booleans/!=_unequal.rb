p "123" != 123

p 5 > 3

sen = "a confusing /:sentence:/[ this is not!!!!!!!~"

p sen.split().each { |i| i.length }
p sen.split()
p sen.split().sort_by(&:length)
