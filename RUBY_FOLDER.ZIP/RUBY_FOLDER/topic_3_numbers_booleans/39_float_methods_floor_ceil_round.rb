
p 10.5.to_i

#cut after "." to down and goes to the IntegerClass
p 10.9.floor
#apper the parameters after "." to up and goes to the IntegerClass
p 10.2.ceil

p 3.1415926.round(3)

p -3.3.abs.round
