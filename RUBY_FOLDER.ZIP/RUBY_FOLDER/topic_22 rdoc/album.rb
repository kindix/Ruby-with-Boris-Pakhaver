# at cmd "rdoc album.rb"
class Album
  include Enumerable
  attr_reader :songs

  def initialize
    @songs = []
  end

  def add_song(song)
    songs << song
  end

  def each
    songs.each { |song| yield song }
  end
end

tr = Album.new
tr.add_song("Treveler")
tr.add_song("Lora")

p tr.each { |song| p song.upcase}


def custom_join(*args)
    args.join(" ")
end

p custom_join("Hello", "World", "That", "Working")
