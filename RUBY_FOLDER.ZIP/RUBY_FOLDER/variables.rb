name = "Andrii"
last_name = "Hrytsanchuk"
handsome = true
age = 33

print name + " " + last_name
