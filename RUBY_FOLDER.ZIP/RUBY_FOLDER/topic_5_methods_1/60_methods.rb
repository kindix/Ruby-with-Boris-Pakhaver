def introduce_myself
  p "Hello im Andrii"
end

5.times {introduce_myself}
