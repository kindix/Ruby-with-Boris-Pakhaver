
def praise_person(name, age = 33)
  p "#{name} your are amazing. You are #{age} years old." 
end


praise_person("Andrii")
praise_person("Borris", 25)
