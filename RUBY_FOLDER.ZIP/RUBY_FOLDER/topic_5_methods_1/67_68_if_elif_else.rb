
color = "Black"

if color == "Grey"
  p "Color is Grey"
elsif color == "Black"
  p "Great!"
end


# else here

grade = "C"

if grade == "A"
  p "Ok, its exellent take a cookie"
elsif grade == "B"
  p "Ok, but without cookies"
else
  p "No, go away"
end


def odd_or_even(num)
  if num.odd?
    "#{num} is odd"
  else
    "#{num} is even"
  end
end


p odd_or_even(4)
