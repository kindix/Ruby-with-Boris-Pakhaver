def meal_plan(time_of_week, time_of_day)
  if time_of_week == "weekday"
    if time_of_day == "breakfast"
      "Tea"
    elsif time_of_day == "lunch"
      "Toast"
    elsif time_of_day == "dinner"
      "Pizza"
    end
  elsif time_of_week == "weekend"
    if time_of_day == "breakfast"
      "Coffe"
    elsif time_of_day == "lunch"
      "Toast_2"
    elsif time_of_day == "dinner"
      "Pizza_2"
    end
  end
end

p meal_plan("weekend", "lunch")
