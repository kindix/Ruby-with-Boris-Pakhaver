def introduce_myself
  expression = "Im a genius"
  p "Hello im Andrii"
  p expression
end

introduce_myself
 
