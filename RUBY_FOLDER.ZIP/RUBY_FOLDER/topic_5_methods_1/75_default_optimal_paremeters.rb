def make_phone_calling(number, international_number = 3, operator_number = 66)
  p "Calling +#{international_number}-0#{operator_number}-#{number}"
end

make_phone_calling("49-400-95")
