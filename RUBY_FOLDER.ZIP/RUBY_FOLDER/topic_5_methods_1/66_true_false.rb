#only two falsey values

  false
  nil

if []
  p "Good"
end
