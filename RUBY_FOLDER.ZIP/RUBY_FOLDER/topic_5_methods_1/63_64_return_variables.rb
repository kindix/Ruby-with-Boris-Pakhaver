
def add_two_numbers(num1, num2)
  return num1 + num2
  # everything what after RETURN dont do
end

p add_two_numbers(2, 3)

def nothing
  "nothing"
end

p nothing
