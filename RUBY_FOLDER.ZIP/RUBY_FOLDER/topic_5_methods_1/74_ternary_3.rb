if 1 > 2
  p "Ok"
else
  p "No way"
end


p 1 > 2 ? "Ok" : "No way"


def even_or_odd(num)
  if num.even?
    p "#{num} is even"
  else
    p "#{num} is odd"
  end
end

even_or_odd(5)

p 5.even? ? "yes" : "no"
