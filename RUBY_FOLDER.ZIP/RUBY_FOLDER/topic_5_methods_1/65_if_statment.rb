num = 5

if num > 3
  p num
end
