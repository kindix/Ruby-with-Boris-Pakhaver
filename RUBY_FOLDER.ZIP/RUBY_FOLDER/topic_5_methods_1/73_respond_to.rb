num = 1000

p num.respond_to?("next", "length")
p num.respond_to?(:is_a?)
