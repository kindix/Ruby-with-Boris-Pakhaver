def authenticate_agent(rank, name, credential)
  if (rank == "007" && name == "Bond") || credential == "Sectet agent"
    p "Good job, come in in"
  end
end


authenticate_agent("007", "Bond", "SPY")
