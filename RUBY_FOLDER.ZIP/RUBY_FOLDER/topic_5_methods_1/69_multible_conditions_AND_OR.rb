# and = &&

# && means in if many condirionals must be a TRUE

age = 33
ticket = "Mystic Festival 2023"
id = false

if age > 21 && ticket && id
  p "Congratulations, move on stage #{ticket}"
end


# or = ||

if age > 18 || ticket || id
  p "2. Congratulations, move on stage #{ticket}"
end
