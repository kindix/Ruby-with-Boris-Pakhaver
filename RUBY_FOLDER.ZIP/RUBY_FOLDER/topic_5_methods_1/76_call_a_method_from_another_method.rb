def add(a, b)
  a + b
end

def subtract(a, b)
  a - b
end

def multyply(a, b)
  a * b
end

def calculator(a, b, operator = "add")
  if operator == "add"
    "The result of adding is #{add(a, b)}"
  elsif operator == "subtract"
    "The result of subtrackig is #{subtract(a, b)}"
  elsif operator == "multyply"
    multyply(a, b)
  end
end



p calculator(1, 4, "subtract")
