story = <<MSL
Hello. My name is Andrii. I am 33 years old.
And only now Im starting to learn RUBY
MSL
# look at 136 too
# puts story
#
p story.split("")
p story.chars

def longest_words(str)
  all_longest = []
  longest_word = str.split.max { |a, b| a.length <=> b.length }
  # str.split.each { |word| all_longest << word if word == longest_word}
end

p longest_words(story)

p story.split.sort_by { |word| word.length} [-1]
