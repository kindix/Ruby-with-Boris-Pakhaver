fact = "I am  veery    haandsome."

# p fact.clear

word = "Hello world"

p word.delete("He")


def custom_delete(str, substr)
  new_str = ""
  str.each_char { |char| new_str << char unless substr.include?(char) }
  new_str
end

p custom_delete(word, "He") == word.delete("He")
