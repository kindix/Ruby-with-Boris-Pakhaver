fact = "I am  veery    haandsome."

p fact.squeeze(" ea")    # delete повтори
fact.squeeze!(" ")
p fact


def custom_squeeze(str)
  new_str = ""
  chars = str.split("")
  chars.each_with_index { |letter, index| letter != chars[index + 1] ? new_str << letter : next }
  new_str
end

p custom_squeeze(fact)
