str = "Hello world"

str.each_char { |letter| p letter}

name = "Andrii"

p name.split("")
p name.chars
