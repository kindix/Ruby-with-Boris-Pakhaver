names = %w[Joe Moo Bob]

p names.join(" ")

def custom_join(arr, delimiter = "")
  str = ""
  last_index = arr.length - 1
  arr.each_with_index do |elem, index|
    str << elem
    str << delimiter if index != last_index
  end
  str
end

p custom_join(names, "-")
