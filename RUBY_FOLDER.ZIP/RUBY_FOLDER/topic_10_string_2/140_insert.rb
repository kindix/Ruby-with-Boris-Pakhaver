typo = "GeorgWashinhton"

p typo.insert(5, "e ")
