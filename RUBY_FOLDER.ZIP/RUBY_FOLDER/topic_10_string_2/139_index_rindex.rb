fact = "I am very handsome."

p fact.index("am")

p fact.rindex("e") #reverse index


def custom_index(str, substr)
  return nil unless str.include?(substr)
  length = substr.length
  str.chars.each_with_index { |elem, index|
    seq = str[index, length]
    return index if seq == substr}
end

p custom_index(fact, "am")
