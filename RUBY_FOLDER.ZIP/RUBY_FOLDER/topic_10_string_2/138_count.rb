word = "Hello world" #gives 5 becouse find how many "o" + "l"

# word.chars { |j| p "Letter #{j} in a word is #{word.count(j)} times"}



def custom_count(srt, search_char)
  result = 0
  srt.each_char { |char| result += 1 if search_char.include?(char) }
  result
end


p custom_count(word, "lo")
