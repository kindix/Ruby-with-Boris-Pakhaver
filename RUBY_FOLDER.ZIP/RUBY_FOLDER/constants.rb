age = 33

p age

NAME = "Andrii"
PI = 3.1415926

p "My name is #{NAME}"
