

p "hello".capitalize
p "HeLLo".capitalize
p "HeLLo".swapcase
