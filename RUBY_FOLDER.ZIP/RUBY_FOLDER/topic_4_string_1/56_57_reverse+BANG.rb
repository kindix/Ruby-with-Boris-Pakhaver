word = "Ruby"

p word.reverse

p word

puts

p word.upcase!

p word
