

p "Hello world"
p "Say 'Goodbye'!"
puts'Say "Goodbye"!'

puts "Say \"Goodbye\"!"

rezult =  "Line break\nhere\n"

p rezult.chomp

#tabs

rezult_second = "\tHello world"

puts rezult_second.gsub("\t", "")
