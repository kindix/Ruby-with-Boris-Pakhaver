
# "\n" or any with "\ " at '' does not working

puts "Hello\nworld"
puts '\tHello\nworld'

# interpolation does not working too

rezult = "Hello world"
puts "#{rezult}"
puts '#{rezult}'
