words = <<MSL
  Hello
World
MSL

puts words


def here_doc
  <<-HERE
  Hello World
  and others!
  HERE
end


puts here_doc

p Encoding.list
