name = String.new("Andrii")
p name

name_easy = "Andrii"
puts
p name_easy

puts
p 5.to_s
