  story = "This method looks for partial words & instead
  of returning true or false it will give you the index
  where the start of this string is found."

  p story[150]
  p story.gsub(/\w+/) {|i| i.capitalize}
  p story.slice(0, 4) # 4 here is a how many characters show
  p story[1..10]
  p story[1...10] #not include 10


  puts story
