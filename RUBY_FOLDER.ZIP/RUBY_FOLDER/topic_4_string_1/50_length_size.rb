
first_name = "Andrii"
second_name = "Hrytsanchuk"

p first_name.length
p first_name.size
p first_name.index("i")
