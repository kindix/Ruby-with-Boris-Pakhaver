story = <<MSL
This method looks for partial words & instead
of returning true or false it will give you the index
where the start of this string is found
MSL

story[2] = "u"

puts story.gsub("Thus", "Thouse")
p story.tap {|a| a.capitalize}
p story.gsub(/\w+/) {|i| i.capitalize}
