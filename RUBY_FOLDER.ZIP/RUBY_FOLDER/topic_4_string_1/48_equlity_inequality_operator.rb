
a = "Hello"
b = "hello"
c = "HELLO"

p b == c.downcase
p a != b
p a < c
puts
p "" > "b"
