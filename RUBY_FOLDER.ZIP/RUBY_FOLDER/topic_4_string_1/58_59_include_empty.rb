
word = "hello 5 world"

#p word.include?("5")



p "".empty?
p "".nil?
