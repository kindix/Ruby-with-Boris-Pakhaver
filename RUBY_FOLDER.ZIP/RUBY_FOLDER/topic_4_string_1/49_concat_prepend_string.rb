first_name = "Andrii"
second_name = "Hrytsanchuk"


p first_name << second_name
p first_name
p first_name.concat(second_name)
puts
# second_name put before first_name
p first_name.prepend(second_name)
