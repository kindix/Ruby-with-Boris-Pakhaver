def calc_total(price, tip, tax)
  tax_amount = price * tax
  tip_amount = price * tip
  price + tip_amount + tax_amount
end

p calc_total(50, 0.05, 0.195)


def calc_total_2(info)
  tax_amount = info[:price] * info[:tax]
  tip_amount = info[:price] * info[:tip]
  info[:price] + tip_amount + tax_amount
end

p calc_total_2(price: 50, tax: 0.195, tip: 0.05)
