person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}

p person.to_a.flatten.map { |item| item.class == Symbol ? item.to_s : item}


power_rangers = [[:red, "Jason"], [:black, "Zack"]]

p power_rangers.to_h


new_person = Hash[hello: 3, me: "Andrii"]

p new_person
