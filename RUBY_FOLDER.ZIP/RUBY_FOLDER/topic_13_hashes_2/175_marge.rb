person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}

          players = {"Jordan" => "Chicago",
                      "Oniel" => "New Jersey",
                      "Romo" => "New_England",
                       age: 25}


p person.merge(players)


def custom_hash(hash_1, hash_2)
  new_hash = hash_1.dup
  hash_2.each { |k, v| new_hash[k] = v }
  new_hash
end


p custom_hash(person, players)
