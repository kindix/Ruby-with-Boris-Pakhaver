person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}

person.delete(:name)

p person
