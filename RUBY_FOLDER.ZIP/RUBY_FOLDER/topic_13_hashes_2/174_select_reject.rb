person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}

new_person = person.select { |k, v| Hash[k: v] if v.is_a?(String)}
delete_is = person.reject { |k, v| Hash[k: v] if v.is_a?(String)}
new_person_2, delete_is_2 = person.partition {|k, v| v.is_a?(String)}

p new_person
p delete_is
puts

p new_person_2
p delete_is_2
