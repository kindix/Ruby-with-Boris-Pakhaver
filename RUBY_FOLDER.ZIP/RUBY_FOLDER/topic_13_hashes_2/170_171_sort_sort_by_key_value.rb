person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}

p person.sort_by { |k, v| k }.reverse.to_h


p person.key?(:name)
p person.value?(33)
