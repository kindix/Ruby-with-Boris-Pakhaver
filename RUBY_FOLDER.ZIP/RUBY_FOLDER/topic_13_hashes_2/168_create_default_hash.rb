

person = Hash.new(0)

person[:name] = "Andrii"
person[:sec_name] = "Hrytsanchuk"

# person.default = "Bey"

p person[:size]
