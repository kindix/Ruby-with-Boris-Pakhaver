

alphabet = "A".."z"


alphabet.find_all {|a| p a if a == "A"}

p alphabet.include?("A")
p alphabet === "A"
