nums = 1..10

p (1..10).first(3)

nums_size  = nums.size
nums.first(nums_size).find_all {|i| p i if i % 2 == 0}


def new_range(i, j)
  i..j
end

p new_range(1,4)

p Range.new(0,2)
