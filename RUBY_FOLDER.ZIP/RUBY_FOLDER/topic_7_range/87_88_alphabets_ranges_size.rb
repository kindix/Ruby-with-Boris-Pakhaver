
alphabet = "A".."z"

p alphabet.first(52)


p alphabet.to_a.size()
