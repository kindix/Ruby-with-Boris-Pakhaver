
a = rand(1000)
b = rand(1000)

p Range.new(a, b) if a < b

number = rand.round(5)
p number.to_s.length
p number
