# a = 10
# b = 20
# c = 30

a, b, c = 10, 20, 30

p a, b, c
# p b
# p c


d = 1
f = 2

p d, f

d, f = f, d

p d, f
