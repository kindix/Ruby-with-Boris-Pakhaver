birthday = Time.new(2022, 5, 6, 9, 15, 0)
summer = Time.new(2022, 6, 21)
independens = Time.new(2022, 8, 24)
winter = Time.new(2022, 12, 21)

p birthday.to_s
p birthday.to_a
p birthday.ctime

p winter.strftime ("%H:%M:%S %z %d-%b-%Y")
