curr_time = Time.new
p curr_time.strftime ("%H:%M:%S %z %d-%m-%Y")
p curr_time.hour
p curr_time.min
p curr_time.sec

time_new = Time.new(2011, 9, 11, 10, 00, 00)
p time_new.class
p time_new.year
p time_new.month
p time_new.day

puts "========================================="
p time_new.yday
p time_new.wday  #0 -is Sunday
