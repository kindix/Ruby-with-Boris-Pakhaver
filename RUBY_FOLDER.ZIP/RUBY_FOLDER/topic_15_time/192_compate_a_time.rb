birthday = Time.new(2022, 5, 6)
summer = Time.new(2022, 6, 21)
independens = Time.new(2022, 8, 24)
winter = Time.new(2022, 12, 21)


p birthday < summer
p independens.between?(summer, winter)
