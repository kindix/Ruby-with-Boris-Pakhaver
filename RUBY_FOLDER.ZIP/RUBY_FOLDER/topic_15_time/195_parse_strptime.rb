require "time"

p Time.parse("06-05-1989")
p Time.strptime("18-09-2022", "%d-%m-%Y")
