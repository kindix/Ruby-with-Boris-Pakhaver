birthday = Time.new(1989, 5, 6)

p ((Time.now - birthday)/86400/365).round

def find_day_of_year_by_number(num)
  curr_day = Time.new(2022, 1, 1)
  one_day = 86400
  until curr_day.yday == num
   curr_day += one_day
  end
  curr_day
end

p find_day_of_year_by_number(150)

def find_day_of_year_by_number(num)
  curr_day = Time.new(2022, 1, 1)
  one_day = 86400
  return curr_day + (num - 1) * one_day
end

p find_day_of_year_by_number(150)
