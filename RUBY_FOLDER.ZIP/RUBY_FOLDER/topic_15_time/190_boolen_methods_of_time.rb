birthday = Time.new(1989, 5, 6)
p birthday.saturday?

p birthday.dst? #same ady in the week


p (Time.now - birthday)/86400/365
