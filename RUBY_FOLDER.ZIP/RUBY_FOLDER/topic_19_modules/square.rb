module Square
  def self.area(side)
    side * side
  end
end
