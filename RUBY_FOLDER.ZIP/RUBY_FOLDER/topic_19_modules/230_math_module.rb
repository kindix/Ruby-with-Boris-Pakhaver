p Math::PI

p Math.sqrt(16)
p Math.sin(180)
