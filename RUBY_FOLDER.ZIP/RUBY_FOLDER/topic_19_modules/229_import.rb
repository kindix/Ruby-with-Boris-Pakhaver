require "d:/Ruby31-x64/RUBY_FOLDER/topic_19_modules/228_indectical_method.rb" # or like that, why I dont know "./228_indectical_method.rb"
require_relative "square"

p Square.area(5)


#require_relative -- use always this syntax (find in the same directory)
