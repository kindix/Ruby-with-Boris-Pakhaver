module Purchaseble
  def purchase(item)
    "#{item} has been purchased from module"
  end
end

class BookStore
  include Purchaseble
end

class Jornal
  def purchase(item)
    "#{item} has been purchased from class "
  end
end

new_book = BookStore.new
new_jornal = Jornal.new

p new_book.purchase([])
p new_jornal.purchase("This new jornal")

p BookStore.ancestors
