module Triangle
  def self.area(side, height)
    side * height / 2
  end
end

module Circle
  PI = 3.1415926
  def self.area(radius)
    PI * radius * radius
  end
end


p Circle.area(5)
p Triangle.area(4.5, 10)
