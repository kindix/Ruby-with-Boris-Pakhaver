p Kernel.is_a?(Module)

module Purchaseble
  def purchase(item)
    "#{item} has been purchased from module"
  end
end

module Announcer
  def who_am_i
    "This is #{self}"
  end
end

class Jornal
  prepend Purchaseble # first find in a module before instance methods in class and "extend" work in a class
  extend Announcer
  def purchase(item)
    "#{item} has been purchased from class"
  end
end

new_jornal = Jornal.new
p Jornal.ancestors

p new_jornal.purchase("1")

p Jornal.who_am_i
