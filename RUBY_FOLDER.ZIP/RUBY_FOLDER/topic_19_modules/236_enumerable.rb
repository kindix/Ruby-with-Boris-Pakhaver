p Array.ancestors

p Enumerable.is_a?(Module)

class ConvenienceStore
  include Enumerable

  attr_reader :snacks

  def initialize
    @snacks = []
  end

  def add_snack(snack)
    snacks << snack
  end

  def each
    snacks.each { |snack|
      yield snack}
  end
end


bodega = ConvenienceStore.new
bodega.add_snack("Pizza")
bodega.add_snack("Burger")
bodega.add_snack("Cola")

p bodega.snacks

bodega.each_with_index { |snack, index| p "#{index}: #{snack}" if snack == "Pizza"}

p bodega.sort_by { |snack| snack.length}

p bodega.first
