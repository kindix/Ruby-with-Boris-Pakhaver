puts "Hi, what's your name?"
name = gets.chomp

puts "Great #{name}. What's your age?"
age = gets.chomp.to_i

puts "Cool, nice to meet you #{name} your age is #{age}."
