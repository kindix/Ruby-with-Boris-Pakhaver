class Gadget

  # attr_accessor :user_name #setter and getter in one time
  attr_reader :product_num, :user_name # getter
  attr_writer :password, :user_name  # setter

  def initialize
    @user_name = "user #{rand(1..99)}"
    @password = "topsecret"
    @product_num = "#{("A".."z").to_a.sample(3).join}-#{rand(1..999)}"
  end

  def to_s
    "This #{@product_num} has username = #{@user_name}. Its created by
#{self.class} class and has ID #{self.object_id}"
  end

  def user_name # getter
    @user_name
  end

  def password=(new_password) #setter
    @password = new_password
  end
end

phone = Gadget.new

puts phone.user_name
# p phone.password=("123114")
p phone.user_name=("NEW ONE")

p phone.instance_eval { @password }
p phone.instance_eval { to_s }
