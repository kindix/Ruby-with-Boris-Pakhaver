class Gadget

  # attr_accessor :user_name #setter and getter in one time
  attr_reader :product_num, :user_name # getter
  attr_writer :password, :user_name  # setter

  def initialize(user_name = nil, password = nil)
    @user_name = user_name
    @password = password
    @product_num = "#{("A".."z").to_a.sample(3).join}-#{rand(1..999)}"
  end

  def to_s
    "This #{@product_num} has username = #{@user_name}. Its created by
#{self.class} class and has ID #{self.object_id}"
  end
end

phone = Gadget.new("SAMSUNG", "5665230")
new_one = Gadget.new

phone.user_name = "LG"
p phone.user_name
p new_one.to_s
p new_one.user_name
