class Gadget
end

p Gadget.new.class.superclass.methods

phone = Gadget.new
laptop = Gadget.new
tablet = Gadget.new.object_id
