p lambda {}.class

value = 5.3

p 5.3.is_a?(Numeric)
p value.class                                  # Float
p value.class.superclass                       # Numeric
p value.class.superclass.superclass            # Object
p value.class.superclass.superclass.superclass # BasicObject
puts
p "lskjhflshf6???4".scan(/[\d?\d]+/)


p Proc.new {}.class.ancestors
puts Array.class.methods.sort
p 3.1415926
