puts "Hello World"
puts "I'm a live and well!"

puts 5
puts 3 + 4

puts "32" + "3"
