puts "Steven Seagal"
p "Steven Seagal"

puts "This is a
big line break"

puts

p "This is a
big line break"
