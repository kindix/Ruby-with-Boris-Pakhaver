require 'bigdecimal'


p 2**(1/4)
p a = (2**0.333333333333333333333333).round(6)
p Float::MAX

p 0.4 - 0.3 == 0.1


b = BigDecimal("0.1")

p b.class

p 9909090909090909998798987998788798798876768768768787687687687678.class
