class Bicycle
  @@maker = "Checker Pig"
  @@count  = 0
  def self.description
    "Hi Im from #{self.superclass} it means everywere in that class and we dont need to create a object of class"
  end

  def self.count #getter
    @@count
  end

  def initialize
    @@count += 1
  end
end

p Bicycle.description
p Bicycle.count

a = Bicycle.new
b = Bicycle.new
c = Bicycle.new
p Bicycle.count
