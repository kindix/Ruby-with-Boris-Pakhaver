class Book
  def initialize(title, author, pages)
    @title = title
    @author = author
    @pages = pages
  end
end



class Book
  def read
    1.step(@pages, 10) { |page| p "Reading page #{page}...."}
    "#{@title} is done"
  end
end

p new_one = Book.new("7 Habits", "Covey", 382)

p new_one.read
