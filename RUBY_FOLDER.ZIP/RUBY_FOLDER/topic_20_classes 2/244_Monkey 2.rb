class Hash
  def indentify_duplicate_values
    values = []
    dupes = []
    self.each_value { |value| values.include?(value) ? dupes << value : values << value}
    dupes.uniq
  end
end

class Integer
  def seconds
    self
  end

  def minutes_to_sec
    self * 60
  end

  def hour_to_sec
    self * 3600
  end

  def days_to_sec
    self * 86400
  end
end

p Time.now + 60.days_to_sec
