require_relative "242_structs_app_store"
class Gadget

  attr_accessor :user_name  # setter and getter in one time
  attr_reader :product_num, :apps # getter
  # attr_writer :password # setter

  def initialize(user_name = nil, password = nil) # privat method
    @user_name = user_name
    @password = password
    @product_num = generate_product_num
    @apps = []
  end

  def to_s
    "This #{product_num} has username = #{@user_name}. Its created by
#{self.class} class and has ID #{self.object_id}"
  end

  def install_app(name)
    app = AppStore.find_app(name)
    @apps << app unless @apps.include?(app)
  end

  def delete_app(name)
    app = apps.find { |instaled_app| instaled_app.name == name }
    apps.delete(app) unless app.nil?
  end

  def reset(user_name, password)
    self.user_name = user_name
    self.password = password
    self.apps = []
  end

  def password=(new_password)
      @password = new_password if validation_password(new_password)
  end

  private # private all method after

  attr_writer :apps

  def generate_product_num
    start_digits = rand(1000..9999)
    end_digits = rand(1000..9999)
    alphabet = ("A".."Z").to_a.sample(5).join
    midle_digit = "2017"
    "#{start_digits}-#{midle_digit}#{alphabet}-#{end_digits}"
  end

  def validation_password(new_password)
    new_password.is_a?(String) && new_password =~ /\d/ && new_password.length >= 6
  end
end

phone = Gadget.new("SAMSUNG", 5665230)
# p phone.generate_product_num


p phone.to_s
phone.password=("adadad5adadad")
p phone.instance_eval { @password }
# p phone.password

phone.install_app(:Chat)
phone.install_app(:Twitter)
phone.delete_app(:Chat)

p phone.apps
