class Array

  def sum_2
    total = 0
    self.inject(:+)
  end

  def sum
    total = 0
    self.each { |element| total += element if element.is_a?(Numeric)}
    total
  end
end


p [1, 2, 3, "Hello"].join.scan(/\d/).map { |elem| elem.to_i}.inject(:+)
p [1, 2, 3, "Hello"].sum


class String
  def alphabet_sum
    alphabet = ("a".."z").to_a

    sum = 0
    self.downcase.each_char { |char| sum += (alphabet.index(char) + 1) if alphabet.include?(char)}
    sum
  end
end

p "Hello I am here".alphabet_sum
