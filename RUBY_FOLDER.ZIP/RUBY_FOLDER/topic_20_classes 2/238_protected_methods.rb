class Car

  # attr_accessor :value

  def initialize(age, miles)
    base_value = 20000
    age_deduction = age *20
    miles_deduction = miles / 10.0
    @value = base_value - age_deduction - miles_deduction
  end

  def compare_car_with(car)
    self.value > car.value ? "Your car is better" : "You car is worst"
  end

  protected

  def value
    @value
  end
end


car_1 = Car.new(1, 5000)
car_2 = Car.new(10, 130000)

p car_2.compare_car_with(car_1)
p Car.value
p car_2.instance_eval { @value }
