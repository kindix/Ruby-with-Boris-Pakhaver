p 1 + 2
p 1 - 2
p 1 * 2

puts

p "School" + "bus"

p 5 / 3
p 5 / 3.0


p 4 ** 2 #power

p 5 % 3 #залишок (modulo)
