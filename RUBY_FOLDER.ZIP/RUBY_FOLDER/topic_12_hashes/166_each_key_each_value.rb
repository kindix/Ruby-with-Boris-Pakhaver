person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}


person.each_key { |k| p k}
person.each_value { |v| p v}


def custom_(hash)
  keys = []
  values = []
  hash.each { |k, v|
    keys << k
    values << v }
  p keys
  p values
end

custom_(person)
