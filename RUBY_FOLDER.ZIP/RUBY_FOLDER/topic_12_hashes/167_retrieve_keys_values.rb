person = {:name => "Andrii",
          :age => 33,
          :handsome => true,
          :language => "Ruby"}


p person.keys

states = {NJ: "New Jersey", NY: "New York", KY: "Kansas"}
states[:KY] = "Kentucky"
p states[:KY]
