p new_hash ={}.empty?

players = {"Jordan" => "Chicago",
            "Oniel" => "New Jersey",
            "Romo" => "New_England"}

nba_roster = {"Cleveland" => ["Lebrown", "Love", "Irving"],
              "Golden State" => ["Curry", "Klay"] }

p nba_roster["Golden State"]
