person_new = {name: "Andrii",
              age: 33,
              handsome: true,
              language: "Ruby"}

person_new.each {|k| p k[0]  }



def value_count(hash, value)
    result = []
    hash.each { |k, v| result << v if v == value}
    p result.length
end


    hash = { a: 5, b: 2, c: 3, d: 5 }

   value_count(hash, 2)
