person_new = {name: "Andrii",
              age: 33,
              handsome: true,
              language: "Ruby"}

person_new[:length] = 171

person_new.store(:size, 40.667)

p person_new
