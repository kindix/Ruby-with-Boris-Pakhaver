person_new = {name: "Andrii",
              age: 33,
              handsome: true,
              language: "Ruby"}

p person_new.fetch(:size, nil)

p person_new
