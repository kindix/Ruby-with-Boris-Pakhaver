

p :age.to_s

p "age".to_sym
