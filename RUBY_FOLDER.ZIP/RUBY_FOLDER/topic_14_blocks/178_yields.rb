def pass_control
  p "Start here"
  yield
  p "Come back"
end
pass_control {p "Im inside the block"}
puts

def who_am_i
  result = yield
  p "I am #{result}"
end
who_am_i {"Andrii"}
puts


def multy_pass
  p "Start here"
  yield
  p "Come back"
  yield
end

multy_pass {p "Block now"}
