evens = [2, 4, 6, 8, 10, 12, 14]
odds = [1, 3, 5, 7, 9, 11, 13]

evens.each { |num| p num * 2 }
result = evens.map { |num| num * 2 }
p result


5.times { |index| puts "Let's go next #{index.next}"}

p Class.methods
