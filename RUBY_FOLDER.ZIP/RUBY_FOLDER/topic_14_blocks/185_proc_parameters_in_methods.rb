def talk_about(name, &my_proc)
  p "Let me tell about #{name}"
  my_proc.call(name)
end

good_things = Proc.new { |name| p "#{name} is an genius"}
bad_things =  Proc.new { |name| p "#{name} is an bad guy "}

talk_about("Andrii", &good_things)
