a_proc = Proc.new { |entry_value, *values| values.map { |value| value * entry_value } }

p a_proc.call(3, 1, 2, 3)

def custom_proc(entry_value, *values)
  values.map { |value| value * entry_value }
end

p custom_proc(3, 1, 2, 3) == a_proc.call(3, 1, 2, 3)
puts "======================================"

a = [1, 2, 3, 4, 5]
b = [6, 7, 8, 9, 10]
c = [11, 12, 13, 14, 15]
d = [16, 17, 18, 19, 20]

cubes = Proc.new { |*arrs| arrs.map { |arr| arr. map { |value| value **2 } } }
p cubes.call(a)

puts "======================================"

custom_cubes = Proc.new { |value| value **3 }
p a.map(&custom_cubes)
a_cubes, b_cubes, c_cubes = [a, b, c].map { |array| array.map(&custom_cubes) }
p a_cubes, b_cubes, c_cubes

puts "======================================"

curr = [10, 20, 30, 40, 50]

to_euro = Proc.new { |array| array.map {|elem| (elem * 0.94).round(3)}}

# p curr.map(&to_euro)
p to_euro.call(curr)


puts "======================================"

ages = [19, 34, 45, 12, 38, 53, 36, 18, 56, 80, 90]

old_and_young = Proc.new { |age| age > 35}

old, young = ages.sort.partition(&old_and_young)

p old
p young
