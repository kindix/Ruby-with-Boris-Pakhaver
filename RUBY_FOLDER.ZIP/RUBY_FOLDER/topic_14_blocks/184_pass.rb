arr = ["1", "2", "3"]

p arr.map { |num| num.to_i}

p arr.map(&:to_i)

p [1, 2, 4].map(&:to_s)




p Object.methods.length
