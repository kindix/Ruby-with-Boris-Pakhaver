def custom_each(array)
  i = 0
  while i < array.length
    yield array[i]
    i += 1
  end
end

names = ["Andrii", "Boris", "Marko"]
numbers = [33, 25, 4]

custom_each(names) { |name| p name }
custom_each(numbers) { |num| p num * 2 }

names.each { |name| p name }
