squares_proc = Proc.new { |x| x**2 }

p [1, 2, 3].map(&squares_proc)
p squares_proc.call(5)

first_lambda = lambda { |x| x**2 }

p [1, 2, 3].map(&first_lambda)
p first_lambda.call(5)
puts "========================================================"
some_proc = Proc.new { |name, age| "My #{name} is, and Iam #{age} years old"}
p some_proc.call("Andrii", 33)

some_lambda = lambda { |name, age| "My #{name} is, and Iam #{age} years old"}

p some_lambda.call("Andrii", 33)
puts "========================================================"

def diet_proc
  status = Proc.new { return "You gave in"}
  status.call
  "You complet the diet"
end

def diet_lambda
  status = lambda { return "You gave in"}
  status.call
  "You complet the diet"
end

p diet_proc
p diet_lambda
