
def pass_control
  p "We on top"
  yield if block_given?
  p "We are on bottom"
end

some_block = Proc.new { p "Block from Proc.new"}

pass_control(&some_block)
