to_euro = Proc.new { |dollar| dollar * 0.95}

def convert(dollar, &my_proc)
  my_proc.call(dollar) if dollar.is_a?(Numeric)
end



p convert(1000, &to_euro)
