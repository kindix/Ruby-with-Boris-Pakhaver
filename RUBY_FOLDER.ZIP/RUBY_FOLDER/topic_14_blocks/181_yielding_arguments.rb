def speak_the_truth(name)
  yield name if block_given?
end

speak_the_truth("Andrii") { |name| p name}


def numbers(num1, num2, num3)
  yield(num1, num2) + num3
end

result = numbers(17, 23, 34) { |num1, num2| num1 * num2 }
p result
