numbers = [1, 2, 3, 5, 6, 7, 8]

p numbers[3..5] == numbers[3, 3]


p numbers[0,1] == numbers[0]
# numbers[0,1] get Array
# numbers[0] get Class of value here is Integer

p numbers[3, 3]
p numbers[3..5]


channels = %w[ICTV New 1+1]
p channels.values_at(0..)


p channels.slice(0)
p channels[0]
