def product_of_even_indices(name_array)
  a = []
  name_array.each_with_index {|value, index| index.odd? ? a.push(value) : "not odd"}
  p a.inject(:+)
end

product_of_even_indices([3, 4, 3, 5, 3, 6,6,5,4,34,5,5,6,6787,243])
