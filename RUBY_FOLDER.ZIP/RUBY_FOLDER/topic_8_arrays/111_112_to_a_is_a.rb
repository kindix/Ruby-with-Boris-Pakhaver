(1..4).to_a

p ("A".."z").to_a.is_a?(Array)


#on the top of inherit class BasicObject and Object

p ("A".."z").to_a.is_a?(Object)
p ("A".."z").to_a.is_a?(BasicObject)

x = ["A", "B", "C"].pop(2)
p x
