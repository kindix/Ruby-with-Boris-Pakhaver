

fruits = %w[Banana Apple Orange Grape]

p fruits.length
p fruits

p fruits[-1] == fruits.[](-1)


p fruits[5] ||= "NoT found"
