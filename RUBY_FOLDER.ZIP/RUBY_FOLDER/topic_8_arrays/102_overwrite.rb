

fruits = %w[Banana Apple Orange Grape]

p fruits[0] = "Potato"

fruits[0..1] = ["Lemon", "Wattermelon"]

fruits[4] = "Rasberry"

fruits[fruits.length + 1] = "Strawberry" # if index bigger than array.length create a "nil"

p fruits

fruits[0..2] = "Blah" # change item 0 and remove 1 and 2

p fruits
