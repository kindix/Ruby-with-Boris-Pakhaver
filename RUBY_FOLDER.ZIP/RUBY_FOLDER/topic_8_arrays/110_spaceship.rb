
a = 2
b = 1

p a <=> b

# if a > b is = 1
# if a = b is = 0
# if a < b is = -1
str =  "if include nil or not same Class is nil"


p [1, 2, 3] <=> ["red", 2, 3]
