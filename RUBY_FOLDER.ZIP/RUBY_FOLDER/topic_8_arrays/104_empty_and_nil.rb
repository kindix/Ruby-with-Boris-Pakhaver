numbers = [1, 2, 4, 6, 4, 7, 8, nil]

p numbers.empty?
p [].empty?
puts
p numbers.nil?

p numbers[100].nil?
