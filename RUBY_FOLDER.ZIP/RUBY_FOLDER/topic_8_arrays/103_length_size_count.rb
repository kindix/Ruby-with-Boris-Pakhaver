
fruits = %w[Banana Apple Orange Grape]
numbers = [1, 2, 3, 5, 6, 7, 8,3, 6, 7, 8, 3, 2]

p "The #{fruits.length} elements in that array done with (length method)"
p "The #{fruits.length} elements in that array done with (size method)"

puts "The #{numbers.count(3)} elements of \"3\" we have "
