fruits = %w[Banana Apple Orange Grape]
numbers = [4, 8, 15, 16, 23, 42]

fruits.push("Lemon")
# p fruits
fruits << "Watermelon"
#p fruits
fruits.insert(1, "Blackberry", "Strawberry")
#p fruits
puts

# p numbers
numbers.pop() # delete last...
p numbers

# numbers.delete(23)
# p numbers
# numbers.delete_at(0)
# p numbers
