
names = %w[Tom Andrii Bob]

p names[1]

p names.fetch(2, "NoT found")
p names.fetch(4, names.push("New name"))

p names.fetch(4, "New name") 
