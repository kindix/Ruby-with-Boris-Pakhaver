
array = %w[Fuck it is working]

p array



Array.new(3) == Array.new(3, nil) # 3 times of "nil"
