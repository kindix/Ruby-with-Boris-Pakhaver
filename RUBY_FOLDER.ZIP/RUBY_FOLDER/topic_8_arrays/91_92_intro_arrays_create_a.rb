a = []

p a.empty?


b = Array.new()
p b


a = [[1,2],
     [3,4]]

p a.flat_map {|i| i}


b = [5,6]

p a.push(b)
