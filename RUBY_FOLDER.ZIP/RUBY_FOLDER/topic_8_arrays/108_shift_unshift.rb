
numbers = [4, 8, 15, 16, 23, 42]


numbers.shift(2) # remove start start
p numbers

numbers.unshift(2, 324) # insert before
p numbers
