fruits = %w[Banana Apple Orange Grape]
numbers = [4, 8, 15, 16, 23, 42]


p numbers.first
p numbers.last(1) == numbers[-1] #different Class

def custom_first(arr, num = 0)
  return arr[0] if num == 0
  arr[0, num]
end

def custom_last(arr, num = 0)
  return arr.last if num == 0
  arr[-num..-1]
end


p custom_first(numbers, 3)
p custom_last(fruits, 2)
