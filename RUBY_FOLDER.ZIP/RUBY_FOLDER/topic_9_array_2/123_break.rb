prizes = %w[Pyrite Pyrite Pyrite Pyrite Gold Pyrite]

i = 0

until i == prizes.length
  current = prizes[i]
  if current == "Gold"
    p "I find it, #{i} in that possition"
    break
  end
  i += 1
end

arr = [1, 2, 3, 4, 5, 6, "Hello", 7, 8]

arr.each {|i| p i.is_a?(Integer) ? i**2 : break}
