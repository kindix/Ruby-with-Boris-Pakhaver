
p "Hello".include?("o")


numbers = [1, 2, 4, 5, 6, 7]

p numbers.include?(100)

numbers.each_with_index {|num, index| p index if num == 5} # .index ## fuck))

p numbers.index(5)
