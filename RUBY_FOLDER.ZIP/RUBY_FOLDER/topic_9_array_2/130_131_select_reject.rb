grades = [100, 30, 34, 68, 47, 97, 35, 65]

p grades.select { |element| element >= 60 } # here only true or false

words =%w[level racecar more pino]

palindromes = words.select { |word| word == word.reverse}
p palindromes

p words.reject { |word| word.include?("c")}
p words.partition { |word| word.include?("c") }

def evens_and_odds(arr)
    # Write your code here
    a, b = arr.partition { |num| num.odd?}
    return a, b
end

p evens_and_odds(grades)
