
names = %w[Andrii Oksana Marko Miia]

# do not use FOR loop
# better is .each
names.map! {|i| i.upcase}

p names
