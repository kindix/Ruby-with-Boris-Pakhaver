5.times do
  |number|
  @square = number*number
end


p @square
