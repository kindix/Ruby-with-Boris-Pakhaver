colors = %w[Red Black Gray Yellow White]

colors.each_with_index {|color, index| p "#{index}: #{color}"}

 numbers = [-1, 2, 1, 3, 4, 6, 2, 7]

sum = 0

 numbers.each_with_index do |num, i|
   result = num * i
   sum +=result
 end
p sum


def product_of_num_and_i(arr)
  new_arr = []
  arr.each_with_index {|num, i| new_arr << (num * i) if num < i}
  p new_arr
end
product_of_num_and_i(numbers)
