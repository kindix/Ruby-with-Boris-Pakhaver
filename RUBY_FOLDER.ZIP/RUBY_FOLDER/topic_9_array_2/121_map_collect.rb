numbers = [1, 2, 3, 4, 5]
squares = []
numbers.each { |number| squares << number **2 }
squares

squares_map = numbers.map { |num| num**2}

squares_map

fahr_temp  = [150, 213, 57, 100, 2, 0]

def convert_to_celcium(arr)
  arr.map { |temp| ((temp - 32) *  5.0 / 9.0).round(2)}
end
new_celcium = convert_to_celcium(fahr_temp)
p new_celcium

def cubes_arr(arr)
  arr.map { |num| num **3}
end

p cubes_arr(numbers)
