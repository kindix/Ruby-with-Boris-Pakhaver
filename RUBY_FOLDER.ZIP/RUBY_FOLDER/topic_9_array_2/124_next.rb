arr = [1, 2, 3, 4, 5, 6, "Hello", 7, 8]

arr.each {|i|
  if i.is_a?(Integer)
    p i**2
  else p "This is not a number"
    next
  end
  }
