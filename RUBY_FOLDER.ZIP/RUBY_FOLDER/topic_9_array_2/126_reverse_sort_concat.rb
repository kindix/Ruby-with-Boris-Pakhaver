arr = %w[Hello World I am Andrii]
p arr
arr.reverse
p arr
arr.reverse!
p arr

arr.sort # ! rename your array

# concat like a push method but mutade a array

arr.concat(["e"])

p arr

def custom_concat(arr1, arr2)
  arr1.concat(arr2)
end

p custom_concat(arr, ["That", "is", "Tricky"])
