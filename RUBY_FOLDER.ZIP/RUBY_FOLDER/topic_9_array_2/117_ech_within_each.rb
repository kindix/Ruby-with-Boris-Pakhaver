
ages = [33, 33, 4, 0]

names = %w[Andrii Oksana Marko Miia]

names.each { |name| ages.each {|age| p "From family #{name} is #{age}" } }
