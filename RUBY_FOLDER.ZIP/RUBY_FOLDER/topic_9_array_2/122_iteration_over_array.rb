animals = %W[Lion Rubbit Scwerl Tiger Zebra]

iterator = 0

# ||= nil look task 84


while iterator < animals.length
  p "#{iterator} => #{animals[iterator]}"
  iterator += 1
end
