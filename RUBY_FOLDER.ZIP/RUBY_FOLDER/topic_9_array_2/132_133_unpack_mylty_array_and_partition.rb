users = [["Bob", 25, "Male"], ["Boris", 25, "Male"], ["Susan", 19, "Female"]]
p users
bob, boris, susan = users

p bob

# partition - look at 130_131 its a select and reject together
