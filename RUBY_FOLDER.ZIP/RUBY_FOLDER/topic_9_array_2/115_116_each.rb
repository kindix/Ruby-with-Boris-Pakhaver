arr = %w[Hello World I am Andrii]

# arr.each {|a| p a}
# arr.each_with_index {|item, index| p item if index [-3..-1]}
#
# names = %w[boo moo joe]
# names.each do |name|
#   name.capitalize!
# end
# p names

fives = []
5.step(100,5) {|i| fives.push(i)}

p fives


def even_or_odd(arr)
  even_arr = []
  odd_arr = []
  arr.each { |number| number.even? ? even_arr.push(number).length : odd_arr << number}
  p even_arr, odd_arr
end

even_or_odd(fives)
