numbers = [4, 8, 15, 16, 23, 42]
letters = %w[A B C D G U S k]
p numbers.max
p numbers.min

p letters.max
p letters.min

def custom_max(arr)
  "Maximum is #{arr.sort[-1]}"
end

def custom_min(arr)
  return nil if arr.empty?
  min_num = arr[0]
  arr.each { |number| min_num = number if number < min_num}
  "Minimun is #{min_num}"
end

p custom_min(numbers)


p custom_max(numbers)
