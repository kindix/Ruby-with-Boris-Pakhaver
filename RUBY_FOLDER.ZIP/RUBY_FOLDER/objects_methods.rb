new_int = "Hello World!".length

p "Hello World!".upcase
p "Hello World!".downcase
p "hello world!".capitalize
p "HELLO WORLD!".downcase.capitalize

p new_int.to_s

puts
puts

foo = "HELLO WORLD!"

p foo.length.next

p new_int.inspect
