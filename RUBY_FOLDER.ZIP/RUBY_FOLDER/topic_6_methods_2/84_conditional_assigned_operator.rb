

# "||=" working only if variable is nil

y = nil
p y

y ||= 5
p y

y ||= 10
p y



word = "hello"
finding = 2

letter =  word[finding]
letter ||= "NOT found"
p letter
