# untill = !while

i = 1

# while i < 10
#   p i
#   i += 1
# end

until i > 9
  p i
  i += 1
end
