def make_my_food(food)
  case food
  when "Steak"
    "Good"
  when "Sushi"
    "Not bad"
  when "Tacos", "Burritos"
    "You a maxican"
  else
    "What is it?"
  end
end

p make_my_food("pizza")


def mark(grade)
  case grade
  when 90..100 then "A"
  when 80..89 then "B"
  when 70..79 then "C"
  when 60..69 then "D"
  else "F"
  end
end


p mark(82)
