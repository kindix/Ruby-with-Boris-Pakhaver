number = 5000

if number > 2500
  p "Huge number"
end


p number > 2500 ? "Huge number!" : ""
p "Huge number" if number > 2500
