# i = 1
#
# while i < 10
#   p i
#   i += 1
# end
#
# status = true

# while status
#   p "Please enter the user name: "
#   username = gets.chomp.downcase
#   if username == "quit" || username == "exit"
#     status = false
#   end
#   p "Please enter your password: "
#   password = gets.chomp
#   if username == "kindix" && password == "5665230Qwe"
#     p "Hello #{username} come in in"
#     status = false
#   elsif password == "exit" || password == "exit"
#     p "Goodbye"
#     status = false
#   else
#     puts "incorect combination with #{username}/ and password = **********"
#   end
# end

i = 1..10

a = [4, 5, 4, 7, 3, 8, 4, 3, 3, 6, 8, 9]

a.find_all {|char| p char if char.even?}
