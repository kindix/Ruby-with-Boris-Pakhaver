

# unless = !if
# if = true
# unless = false



password = "5665230"

unless password == "5665230"
  p "Go away"
else
  p "Good"
end
