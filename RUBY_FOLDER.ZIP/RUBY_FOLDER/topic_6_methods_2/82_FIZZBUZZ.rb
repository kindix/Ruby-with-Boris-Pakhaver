

def fizzbuzz(number)
  i = 1
  while i <= number
    if i % 3 == 0 && i % 5 == 0
      p "#{i} is FizzBuzz"
    elsif i % 3 == 0
      p "#{i} is Fizz"
    elsif i % 5 == 0
      p "#{i} is Buzz"
    end
    i += 1
  end
end


fizzbuzz(90)
