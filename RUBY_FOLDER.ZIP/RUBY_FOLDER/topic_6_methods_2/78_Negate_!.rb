

# "!" = "not"


#!true = false
p !!nil
